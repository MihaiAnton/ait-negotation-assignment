package geniusweb.exampleparties.randompartypy;

import geniusweb.pythonadapter.PythonPartyAdapter;

public class PartyAdapter extends PythonPartyAdapter {

	@Override
	public String getPythonClass() {
		return "RandomParty";
	}

}
